package com.university.stockexchange.main_ui.wallet

data class WalletStockItem(val name: String, val amount: Int, val purchasePrice: Float, val id: Int?)

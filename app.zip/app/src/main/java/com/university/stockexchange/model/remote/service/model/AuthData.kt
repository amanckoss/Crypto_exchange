package com.university.stockexchange.model.remote.service.model

data class AuthData(val status: Boolean, val api_token: String?)

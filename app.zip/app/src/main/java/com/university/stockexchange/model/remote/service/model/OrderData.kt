package com.university.stockexchange.model.remote.service.model

data class OrderData(val status: Boolean, val error: String)

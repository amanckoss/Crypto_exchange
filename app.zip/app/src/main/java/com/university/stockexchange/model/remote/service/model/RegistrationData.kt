package com.university.stockexchange.model.remote.service.model

data class RegistrationData(val status :Boolean, val first_name: List<String>, val surname: List<String>, val email: List<String>, val password: List<String>)
